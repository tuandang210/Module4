create
    definer = root@localhost procedure displayName(IN id int)
BEGIN
    SELECT StudentName FROM students WHERE StudentId=id;
END;

