create
    definer = root@localhost procedure countStudent(IN inputMark int)
BEGIN
    SELECT COUNT(mark) FROM mark WHERE mark > inputMark;
END;

